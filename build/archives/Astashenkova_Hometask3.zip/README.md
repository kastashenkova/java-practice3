# Практика 3. Gradle
## Завдання
- Створити власний плагін і використати його в проєкті. У плагіні щонайменше 2 task.
- Додати щонайменше 1 task в build.gradle.kts

## Реалізація
У файлі *build.gradle.kts* за допомогою створили плагін **NetworkPlugin** з 2 тасками, які прописані в окремих класах директорії **buildSrc**, а також через *tasks.register* додали завдання зі створення zip-архіву з вихідним кодом проєкту.

Структура проєкту відповідає схемі нижче.

```
my-app/
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
├── gradlew
├── gradlew.bat
├── gradle/
    └── wrapper/
        ├── gradle-wrapper.jar
        └── gradle-wrapper.properties
└── buildSrc/
    └── main/java/...
└── src/
    ├── main/java/...
    └── test/java/...
```

**Тематична цілісність створених завдань**: усі реалізовані таски об'єднані однією логікою — підготовка та перевірка мережевого проєкту. Генерація шаблонного сервера, перевірка доступності порту та фінальне пакування коду імітують реальний робочий процес.

## Запуск тасок
У терміналі виконати команди:
- `./gradlew generateTcpServer` (генерує таску з портом 8089) або `./gradlew generateTcpServer -Pport=[номер порту]` (для інших портів)
- `./gradlew checkPort` (перевіряє порт 8089) або `./gradlew checkPort -Pport=[номер порту]` (для інших портів)
- `./gradlew packageHometask`